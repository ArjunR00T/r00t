
public class student {

	student(){}
}
